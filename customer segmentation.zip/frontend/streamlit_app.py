import streamlit as st
import pandas as pd
from pathlib import Path
import plotly.express as px
import requests
import joblib
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import dendrogram


# ==================================================
# 1. PROJECT PATHS
# ==================================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent

OUTPUTS_DIR = PROJECT_ROOT / "outputs"
MODELS_DIR = PROJECT_ROOT / "models"

SEGMENTED_DATA_PATH = (
    OUTPUTS_DIR / "segmented_customers.csv"
)

PCA_DATA_PATH = (
    OUTPUTS_DIR / "pca_visualization.csv"
)

EVALUATION_DATA_PATH = (
    OUTPUTS_DIR / "clustering_evaluation.csv"
)

LINKAGE_PATH = (
    MODELS_DIR / "hierarchical_linkage.pkl"
)


# ==================================================
# 2. PAGE CONFIGURATION
# ==================================================

st.set_page_config(
    page_title="Customer Segmentation Platform",
    page_icon="CS",
    layout="wide"
)


# ==================================================
# 3. LOAD DATA
# ==================================================

df = pd.read_csv(
    SEGMENTED_DATA_PATH
)

pca_df = pd.read_csv(
    PCA_DATA_PATH
)

evaluation_df = pd.read_csv(
    EVALUATION_DATA_PATH
)


# ==================================================
# 4. ADD SEGMENT NAMES TO PCA DATA
# ==================================================

cluster_names = (
    df[
        [
            "cluster",
            "segment_name"
        ]
    ]
    .drop_duplicates()
)

pca_df = pca_df.merge(
    cluster_names,
    on="cluster",
    how="left"
)


# ==================================================
# 5. SIDEBAR NAVIGATION
# ==================================================

st.sidebar.title(
    "Customer Segmentation"
)

page = st.sidebar.radio(
    "Go to",
    [
        "Executive Dashboard",
        "Customer Segmentation",
        "Cluster Visualization",
        "Segment Comparison",
        "Clustering Evaluation",
        "Business Insights"
    ]
)


# ==================================================
# PAGE 1 — EXECUTIVE DASHBOARD
# ==================================================

if page == "Executive Dashboard":

    st.title(
        "Customer Segmentation Platform"
    )

    st.subheader(
        "Executive Dashboard"
    )

    st.write(
        "Explore customer segments discovered through "
        "unsupervised learning."
    )

    st.divider()

    # ----------------------------------------------
    # Key Metrics
    # ----------------------------------------------

    total_customers = len(df)

    total_segments = (
        df["cluster"].nunique()
    )

    cluster_sizes = (
        df["cluster"].value_counts()
    )

    largest_cluster = (
        cluster_sizes.max()
    )

    largest_cluster_percentage = (
        largest_cluster / total_customers
    ) * 100

    total_spend = (
        df["monetary_value"].sum()
    )

    col1, col2, col3, col4 = st.columns(4)

    with col1:

        st.metric(
            "Total Customers",
            f"{total_customers:,}"
        )

    with col2:

        st.metric(
            "Customer Segments",
            total_segments
        )

    with col3:

        st.metric(
            "Largest Segment",
            f"{largest_cluster_percentage:.1f}%"
        )

    with col4:

        st.metric(
            "Total Spend",
            f"₹{total_spend:,.0f}"
        )

    st.divider()

    # ----------------------------------------------
    # Customer Distribution
    # ----------------------------------------------

    st.subheader(
        "Customer Distribution by Segment"
    )

    segment_distribution = (
        df.groupby(
            [
                "cluster",
                "segment_name"
            ]
        )
        .size()
        .reset_index(
            name="customers"
        )
        .sort_values("cluster")
    )

    col1, col2 = st.columns(2)

    with col1:

        fig = px.pie(
            segment_distribution,
            names="segment_name",
            values="customers",
            hole=0.45,
            title="Customer Segment Distribution"
        )

        fig.update_traces(
            textposition="inside",
            textinfo="percent"
        )

        st.plotly_chart(
            fig,
            width="stretch"
        )

    with col2:

        st.dataframe(
            segment_distribution,
            width="stretch",
            hide_index=True
        )

    st.divider()

    # ----------------------------------------------
    # Segment Business Metrics
    # ----------------------------------------------

    st.subheader(
        "Segment Business Metrics"
    )

    segment_metrics = (
        df.groupby(
            [
                "cluster",
                "segment_name"
            ]
        )
        .agg(
            customers=(
                "customer_id",
                "count"
            ),
            avg_frequency=(
                "frequency",
                "mean"
            ),
            avg_monetary_value=(
                "monetary_value",
                "mean"
            ),
            avg_order_value=(
                "avg_order_value",
                "mean"
            ),
            avg_recency=(
                "recency",
                "mean"
            ),
            avg_engagement=(
                "engagement_score",
                "mean"
            ),
            avg_discount_dependency=(
                "discount_dependency",
                "mean"
            )
        )
        .reset_index()
        .sort_values("cluster")
    )

    display_metrics = (
        segment_metrics.rename(
            columns={
                "cluster": "Cluster",
                "segment_name": "Segment",
                "customers": "Customers",
                "avg_frequency": "Avg Frequency",
                "avg_monetary_value": "Avg Monetary Value",
                "avg_order_value": "Avg Order Value",
                "avg_recency": "Avg Recency",
                "avg_engagement": "Avg Engagement",
                "avg_discount_dependency":
                    "Discount Dependency"
            }
        )
    )

    display_metrics[
        "Avg Frequency"
    ] = display_metrics[
        "Avg Frequency"
    ].round(2)

    display_metrics[
        "Avg Monetary Value"
    ] = display_metrics[
        "Avg Monetary Value"
    ].round(2)

    display_metrics[
        "Avg Order Value"
    ] = display_metrics[
        "Avg Order Value"
    ].round(2)

    display_metrics[
        "Avg Recency"
    ] = display_metrics[
        "Avg Recency"
    ].round(2)

    display_metrics[
        "Avg Engagement"
    ] = display_metrics[
        "Avg Engagement"
    ].round(3)

    display_metrics[
        "Discount Dependency"
    ] = display_metrics[
        "Discount Dependency"
    ].round(3)

    st.dataframe(
        display_metrics,
        width="stretch",
        hide_index=True
    )


# ==================================================
# PAGE 2 — CUSTOMER SEGMENTATION
# ==================================================

elif page == "Customer Segmentation":

    st.title(
        "Customer Segmentation"
    )

    st.write(
        "Enter customer information and behavioral data "
        "to discover the customer's segment."
    )

    st.divider()

    # ----------------------------------------------
    # Customer Information
    # ----------------------------------------------

    st.subheader(
        "Customer Information"
    )

    col1, col2, col3 = st.columns(3)

    with col1:

        customer_id = st.text_input(
            "Customer ID",
            value="CUST_NEW_001"
        )

    with col2:

        age = st.number_input(
            "Age",
            min_value=1.0,
            max_value=100.0,
            value=35.0
        )

    with col3:

        location = st.text_input(
            "Location",
            value="Mumbai"
        )

    # ----------------------------------------------
    # Purchase Behavior
    # ----------------------------------------------

    st.subheader(
        "Purchase Behavior"
    )

    col1, col2, col3, col4 = st.columns(4)

    with col1:

        tenure = st.number_input(
            "Tenure (years)",
            min_value=0.1,
            value=3.0
        )

    with col2:

        orders = st.number_input(
            "Orders",
            min_value=0.0,
            value=20.0
        )

    with col3:

        total_spend = st.number_input(
            "Total Spend",
            min_value=0.0,
            value=25000.0
        )

    with col4:

        avg_order_value = st.number_input(
            "Average Order Value",
            min_value=0.0,
            value=1250.0
        )

    col1, col2, col3, col4 = st.columns(4)

    with col1:

        days_since_last_purchase = st.number_input(
            "Days Since Last Purchase",
            min_value=0.0,
            value=30.0
        )

    with col2:

        discount_usage = st.number_input(
            "Discount Usage",
            min_value=0.0,
            max_value=1.0,
            value=0.4
        )

    with col3:

        returns = st.number_input(
            "Returns",
            min_value=0.0,
            value=1.0
        )

    with col4:

        product_categories = st.number_input(
            "Product Categories",
            min_value=0.0,
            value=3.0
        )

    # ----------------------------------------------
    # Engagement Behavior
    # ----------------------------------------------

    st.subheader(
        "Engagement Behavior"
    )

    col1, col2, col3, col4 = st.columns(4)

    with col1:

        website_visits = st.number_input(
            "Website Visits",
            min_value=0.0,
            value=40.0
        )

    with col2:

        app_sessions = st.number_input(
            "App Sessions",
            min_value=0.0,
            value=18.0
        )

    with col3:

        email_interaction = st.number_input(
            "Email Interaction",
            min_value=0.0,
            value=11.0
        )

    with col4:

        wishlist_activity = st.number_input(
            "Wishlist Activity",
            min_value=0.0,
            value=7.0
        )

    col1, col2, col3 = st.columns(3)

    with col1:

        cart_additions = st.number_input(
            "Cart Additions",
            min_value=0.0,
            value=10.0
        )

    with col2:

        cart_abandonment = st.number_input(
            "Cart Abandonment",
            min_value=0.0,
            value=5.0
        )

    with col3:

        support_interactions = st.number_input(
            "Support Interactions",
            min_value=0.0,
            value=2.0
        )

    st.divider()

    # ----------------------------------------------
    # Prediction
    # ----------------------------------------------

    if st.button(
        "Predict Customer Segment",
        type="primary"
    ):

        frequency = (
            orders / tenure
        )

        customer_data = {
            "customer_id": customer_id,
            "age": age,
            "location": location,
            "tenure": tenure,
            "orders": orders,
            "total_spend": total_spend,
            "avg_order_value": avg_order_value,
            "purchase_frequency": frequency,
            "days_since_last_purchase":
                days_since_last_purchase,
            "discount_usage":
                discount_usage,
            "returns": returns,
            "product_categories":
                product_categories,
            "website_visits":
                website_visits,
            "app_sessions":
                app_sessions,
            "email_interaction":
                email_interaction,
            "cart_additions":
                cart_additions,
            "cart_abandonment":
                cart_abandonment,
            "wishlist_activity":
                wishlist_activity,
            "support_interactions":
                support_interactions
        }

        try:

            response = requests.post(
                "http://127.0.0.1:8000/segment",
                json=customer_data,
                timeout=10
            )

            if response.status_code == 200:

                result = response.json()

                st.success(
                    "Customer segmentation completed."
                )

                result_col1, result_col2, result_col3 = (
                    st.columns(3)
                )

                with result_col1:

                    st.metric(
                        "Cluster",
                        result["cluster"]
                    )

                with result_col2:

                    st.metric(
                        "Segment",
                        result["segment_name"]
                    )

                with result_col3:

                    st.metric(
                        "Distance from Centroid",
                        f"{result['distance_from_centroid']:.3f}"
                    )

            else:

                st.error(
                    f"API Error: {response.status_code}"
                )

                st.json(
                    response.json()
                )

        except requests.exceptions.RequestException:

            st.error(
                "Could not connect to the FastAPI server. "
                "Make sure Uvicorn is running on port 8000."
            )


# ==================================================
# PAGE 3 — CLUSTER VISUALIZATION
# ==================================================

elif page == "Cluster Visualization":

    st.title(
        "Cluster Visualization"
    )

    st.write(
        "Visual representation of the discovered customer "
        "segments using PCA and hierarchical clustering."
    )

    st.divider()

    # ----------------------------------------------
    # PCA Scatter Plot
    # ----------------------------------------------

    st.subheader(
        "Customer Segments in 2D PCA Space"
    )

    fig_pca = px.scatter(
        pca_df,
        x="PC1",
        y="PC2",
        color="segment_name",
        hover_data=[
            "customer_id",
            "cluster"
        ],
        title="Customer Segments in 2D PCA Space"
    )

    fig_pca.update_layout(
        xaxis_title="Principal Component 1",
        yaxis_title="Principal Component 2",
        legend_title="Segment"
    )

    st.plotly_chart(
        fig_pca,
        width="stretch"
    )

    st.divider()

    # ----------------------------------------------
    # Hierarchical Dendrogram
    # ----------------------------------------------

    st.subheader(
        "Hierarchical Clustering Dendrogram"
    )

    if LINKAGE_PATH.exists():

        Z = joblib.load(
            LINKAGE_PATH
        )

        fig, ax = plt.subplots(
            figsize=(16, 8)
        )

        dendrogram(
            Z,
            truncate_mode="lastp",
            p=30,
            leaf_rotation=90,
            leaf_font_size=8,
            show_contracted=True,
            ax=ax
        )

        ax.set_title(
            "Hierarchical Clustering Dendrogram"
        )

        ax.set_xlabel(
            "Cluster / Sample Group"
        )

        ax.set_ylabel(
            "Ward Distance"
        )

        plt.tight_layout()

        st.pyplot(
            fig
        )

        plt.close(fig)

    else:

        st.warning(
            "Hierarchical linkage artifact was not found."
        )


# ==================================================
# PAGE 4 — SEGMENT COMPARISON
# ==================================================

elif page == "Segment Comparison":

    st.title(
        "Segment Comparison"
    )

    st.write(
        "Compare behavioral and purchasing characteristics "
        "across the discovered customer segments."
    )

    st.divider()

    comparison_metric = st.selectbox(
        "Select a metric to compare",
        options=[
            "monetary_value",
            "frequency",
            "avg_order_value",
            "recency",
            "engagement_score",
            "discount_dependency",
            "cart_abandonment",
            "returns"
        ],
        format_func=lambda x:
            x.replace("_", " ").title()
    )

    comparison_df = (
        df.groupby(
            [
                "cluster",
                "segment_name"
            ]
        )[comparison_metric]
        .mean()
        .reset_index()
        .sort_values("cluster")
    )

    fig_comparison = px.bar(
        comparison_df,
        x="segment_name",
        y=comparison_metric,
        color="segment_name",
        title=(
            f"{comparison_metric.replace('_', ' ').title()} "
            "by Segment"
        ),
        labels={
            "segment_name": "Segment",
            comparison_metric:
                comparison_metric.replace(
                    "_", " "
                ).title()
        }
    )

    fig_comparison.update_layout(
        showlegend=False,
        xaxis_tickangle=-20
    )

    st.plotly_chart(
        fig_comparison,
        width="stretch"
    )

    st.dataframe(
        comparison_df,
        width="stretch",
        hide_index=True
    )


# ==================================================
# PAGE 5 — CLUSTERING EVALUATION
# ==================================================

elif page == "Clustering Evaluation":

    st.title(
        "Clustering Evaluation"
    )

    st.write(
        "Comparison of the clustering algorithms using "
        "standard unsupervised-learning evaluation metrics."
    )

    st.divider()

    # ----------------------------------------------
    # Evaluation Table
    # ----------------------------------------------

    display_evaluation = (
        evaluation_df.rename(
            columns={
                "algorithm": "Algorithm",
                "silhouette_score":
                    "Silhouette Score",
                "davies_bouldin_index":
                    "Davies-Bouldin Index",
                "calinski_harabasz_score":
                    "Calinski-Harabasz Score",
                "number_of_clusters":
                    "Number of Clusters",
                "noise_points":
                    "Noise Points"
            }
        )
    )

    st.dataframe(
        display_evaluation,
        width="stretch",
        hide_index=True
    )

    st.divider()

    # ----------------------------------------------
    # Metric Selection
    # ----------------------------------------------

    metric_mapping = {
        "Silhouette Score":
            "silhouette_score",

        "Davies-Bouldin Index":
            "davies_bouldin_index",

        "Calinski-Harabasz Score":
            "calinski_harabasz_score"
    }

    selected_metric = st.selectbox(
        "Select evaluation metric",
        options=list(
            metric_mapping.keys()
        )
    )

    metric_column = (
        metric_mapping[selected_metric]
    )

    metric_df = (
        evaluation_df[
            [
                "algorithm",
                metric_column
            ]
        ]
        .dropna()
    )

    fig_evaluation = px.bar(
        metric_df,
        x="algorithm",
        y=metric_column,
        title=(
            f"{selected_metric} by Algorithm"
        ),
        text_auto=".3f"
    )

    fig_evaluation.update_layout(
        xaxis_title="Algorithm",
        yaxis_title=selected_metric
    )

    st.plotly_chart(
        fig_evaluation,
        width="stretch"
    )

    st.info(
        "DBSCAN produced one cluster and three noise points "
        "with the evaluated configuration, so the multi-cluster "
        "evaluation metrics are not reported for that result."
    )


# ==================================================
# PAGE 6 — BUSINESS INSIGHTS
# ==================================================

elif page == "Business Insights":

    st.title(
        "Business Insights"
    )

    st.write(
        "Behavioral characteristics identified from the "
        "customer segments discovered through clustering."
    )

    st.divider()

    # ----------------------------------------------
    # Segment Metrics
    # ----------------------------------------------

    segment_metrics = (
        df.groupby(
            [
                "cluster",
                "segment_name"
            ]
        )
        .agg(
            avg_frequency=(
                "frequency",
                "mean"
            ),
            avg_monetary_value=(
                "monetary_value",
                "mean"
            ),
            avg_recency=(
                "recency",
                "mean"
            ),
            avg_engagement=(
                "engagement_score",
                "mean"
            ),
            avg_discount_dependency=(
                "discount_dependency",
                "mean"
            )
        )
        .reset_index()
        .sort_values("cluster")
    )

    # ----------------------------------------------
    # Overall Reference Values
    # ----------------------------------------------

    overall_frequency = (
        df["frequency"].mean()
    )

    overall_monetary_value = (
        df["monetary_value"].mean()
    )

    overall_recency = (
        df["recency"].mean()
    )

    overall_engagement = (
        df["engagement_score"].mean()
    )

    overall_discount_dependency = (
        df["discount_dependency"].mean()
    )

    # ----------------------------------------------
    # Generate Insights
    # ----------------------------------------------

    for _, row in segment_metrics.iterrows():

        segment = row["segment_name"]

        frequency = (
            row["avg_frequency"]
        )

        monetary_value = (
            row["avg_monetary_value"]
        )

        recency = (
            row["avg_recency"]
        )

        engagement = (
            row["avg_engagement"]
        )

        discount_dependency = (
            row["avg_discount_dependency"]
        )

        cart_abandonment = (
            df[
                df["cluster"] == row["cluster"]
            ]["cart_abandonment"]
            .mean()
        )

        st.subheader(
            segment
        )

        insights = []

        if frequency > overall_frequency:

            insights.append(
                f"Purchase frequency is above the "
                f"overall average ({frequency:.2f})."
            )

        else:

            insights.append(
                f"Purchase frequency is below the "
                f"overall average ({frequency:.2f})."
            )

        if monetary_value > overall_monetary_value:

            insights.append(
                f"Average monetary value is above the "
                f"overall average "
                f"(₹{monetary_value:,.0f})."
            )

        else:

            insights.append(
                f"Average monetary value is below the "
                f"overall average "
                f"(₹{monetary_value:,.0f})."
            )

        if recency < overall_recency:

            insights.append(
                f"Customers have relatively recent "
                f"purchases "
                f"(average recency: "
                f"{recency:.1f} days)."
            )

        else:

            insights.append(
                f"Customers have relatively longer "
                f"purchase gaps "
                f"(average recency: "
                f"{recency:.1f} days)."
            )

        if engagement > overall_engagement:

            insights.append(
                f"Engagement is above the overall "
                f"average ({engagement:.3f})."
            )

        else:

            insights.append(
                f"Engagement is below the overall "
                f"average ({engagement:.3f})."
            )

        if (
            discount_dependency
            > overall_discount_dependency
        ):

            insights.append(
                f"Discount dependency is relatively "
                f"high ({discount_dependency:.3f})."
            )

        else:

            insights.append(
                f"Discount dependency is relatively "
                f"low ({discount_dependency:.3f})."
            )

        if cart_abandonment > (
            df["cart_abandonment"].mean()
        ):

            insights.append(
                f"Cart abandonment is above the "
                f"overall average "
                f"({cart_abandonment:.2f})."
            )

        else:

            insights.append(
                f"Cart abandonment is below the "
                f"overall average "
                f"({cart_abandonment:.2f})."
            )

        for insight in insights:

            st.write(
                f"- {insight}"
            )

        st.divider()